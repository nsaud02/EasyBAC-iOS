# EasyBAC Flutter V1

Flutter source starter with branded screens, Arabic/English/French UI, device-language default and manual override, secure JWT storage, and REST API integration.

## Build
1. Install Flutter SDK 3.24+ and Android Studio/Xcode as appropriate.
2. In this folder run `flutter create . --platforms=android,ios` to generate platform-specific projects.
3. Run `flutter pub get` and `flutter run`.
4. Build with `flutter build apk` or `flutter build ios` (iOS requires macOS and signing).

## API
Base URL: https://easybac.manus.space/api/v1
Supported: signup, login, me, vip/status, vip/activate, catalog, catalog/modules.
Do not embed backend secrets in the client.

## Current limitations
- Catalog JSON response shape was not provided. `extractList` handles common collection keys, but adapt the parsing after testing real JSON.
- The content page opens provided HTTPS media URLs externally; embedded video/PDF playback is not yet implemented.
- No API is documented for favorites, notifications, rewards, progress, Google login, or password reset; these are intentionally not implemented.
- JWT expiresInSeconds in the sample equals one year; backend should consider shorter access tokens and refresh-token support.
- No compiled APK/IPA included. Build and device tests are required.
- The logo asset is the image provided by the client. Confirm permission and quality before publishing.
