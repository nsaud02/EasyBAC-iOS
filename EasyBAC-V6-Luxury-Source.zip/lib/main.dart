
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'api.dart';
import 'translations.dart';

const gold = Color(0xFFF5B83D);
const ink = Color(0xFF121212);
const paper = Color(0xFFF8F7F4);
const softGold = Color(0xFFFFF0D1);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const EasyBacApp());
}

class EasyBacApp extends StatefulWidget {
  const EasyBacApp({super.key});
  @override State<EasyBacApp> createState() => _EasyBacAppState();
}
class _EasyBacAppState extends State<EasyBacApp> {
  final api = EasyApi();
  final storage = const FlutterSecureStorage();
  String language = 'auto';
  bool ready = false;
  String appearance = 'system';
  int tab = 0;
  String? phone;
  int sessionVersion=0;
  @override void initState() {super.initState(); initialize();}
  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    language = prefs.getString('app_language') ?? 'auto';
    appearance = prefs.getString('app_appearance') ?? 'system';
    api.token = await storage.read(key:'access_token');
    phone = await storage.read(key:'phone');
    if(mounted) setState(()=>ready=true);
  }
  Future<void> changeLanguage(String value) async {
    final prefs=await SharedPreferences.getInstance();
    await prefs.setString('app_language',value);
    setState(()=>language=value);
  }
  Future<void> changeAppearance(String value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('app_appearance',value);
    if(mounted) setState(()=>appearance=value);
  }
  Future<void> auth(String number,String password,bool signup) async {
    final result=await api.authenticate(number,password,signup:signup);
    api.token=result['accessToken'] as String;
    phone=number;
    await storage.write(key:'access_token',value:api.token);
    await storage.write(key:'phone',value:number);
    setState((){tab=0;sessionVersion++;});
  }
  Future<void> logout() async {
    await storage.delete(key:'access_token');
    await storage.delete(key:'phone');
    setState(() {api.token=null;phone=null;tab=0;sessionVersion++;});
  }
  @override Widget build(BuildContext context) {
    final system=WidgetsBinding.instance.platformDispatcher.locales;
    final device=system.isEmpty?'en':system.first.languageCode;
    final code=language=='auto'?(['ar','en','fr'].contains(device)?device:'en'):language;
    final locale=Locale(code);
    return MaterialApp(
      title:'EasyBAC', debugShowCheckedModeBanner:false,
      locale:locale, supportedLocales:L.supported,
      localizationsDelegates:const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],

      themeMode: appearance=='dark' ? ThemeMode.dark : appearance=='light' ? ThemeMode.light : ThemeMode.system,
      theme: easyTheme(Brightness.light),
      darkTheme: easyTheme(Brightness.dark),
      home:!ready?const Scaffold(body:Center(child:CircularProgressIndicator())):
      Builder(builder:(context){
        String t(String key)=>L.t(code,key);
        return Scaffold(
          appBar:AppBar(title:Text(tab==0?'EasyBAC':t(['home','subjects','vip','account'][tab]),style:const TextStyle(fontWeight:FontWeight.w900,letterSpacing:.2)),
            actions:[IconButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>SettingsPage(t:t,language:language,onChanged:changeLanguage,appearance:appearance,onAppearanceChanged:changeAppearance))),icon:const Icon(Icons.settings_outlined))]),
          body:IndexedStack(index:tab,children:[
            HomePage(key:ValueKey('home-$sessionVersion'),t:t,api:api,onSubjects:()=>setState(()=>tab=1),onVip:()=>setState(()=>tab=2)),
            CatalogPage(key:ValueKey('catalog-$sessionVersion'),t:t,api:api),
            VipPage(key:ValueKey('vip-$sessionVersion'),t:t,api:api,authenticated:api.token!=null),
            AccountPage(key:ValueKey('account-$sessionVersion'),t:t,api:api,phone:phone,onLogin:()=>openLogin(context,t),onLogout:logout),
          ]),
          extendBody:true,
          bottomNavigationBar: GlassBottomNav(
            selected:tab,
            onSelected:(i)=>setState(()=>tab=i),
            labels:[t('home'),t('subjects'),t('vip'),t('account')],
          ),
        );
      }),
    );
  }
  Future<void> openLogin(BuildContext context,String Function(String) t) async {
    await Navigator.push(context,MaterialPageRoute(builder:(_)=>LoginPage(t:t,onAuth:auth)));
    if(mounted)setState((){});
  }
}

class BrandHeader extends StatelessWidget {
  const BrandHeader({super.key,this.height=125});
  final double height;
  @override Widget build(BuildContext context)=>Center(child:Image.asset('assets/easybac_logo.jpg',height:height,fit:BoxFit.contain));
}
class HomePage extends StatefulWidget {
  const HomePage({super.key,required this.t,required this.api,required this.onSubjects,required this.onVip});
  final String Function(String) t; final EasyApi api; final VoidCallback onSubjects,onVip;
  @override State<HomePage> createState()=>_HomePageState();
}
class _HomePageState extends State<HomePage> {
  late Future<dynamic> future;
  @override void initState(){super.initState();future=widget.api.catalog();}
  @override Widget build(BuildContext context) {
    final dark=Theme.of(context).brightness==Brightness.dark;
    final fg=Theme.of(context).colorScheme.onSurface;
    return RefreshIndicator(onRefresh:()async{setState(()=>future=widget.api.catalog());await future;},
      child:ListView(padding:const EdgeInsets.fromLTRB(20,12,20,132),children:[
        Row(children:[
          Container(width:50,height:50,decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFFFFE6A5),Color(0xFFD99825)]),borderRadius:BorderRadius.circular(18)),child:const Icon(Icons.school_rounded,color:Color(0xFF352109),size:28)),
          const SizedBox(width:13),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text(widget.t('welcome'),style:TextStyle(fontSize:24,fontWeight:FontWeight.w900,color:fg)),
            const SizedBox(height:4),Text(widget.t('subtitle'),style:TextStyle(fontSize:12,color:fg.withValues(alpha:.58)))])),
          const SizedBox(width:4),
        ]),
        const SizedBox(height:18),
        GestureDetector(onTap:widget.onSubjects,child:Container(
          padding:const EdgeInsets.symmetric(horizontal:17,vertical:15),
          decoration:BoxDecoration(color:Theme.of(context).colorScheme.surface,borderRadius:BorderRadius.circular(20)),
          child:Row(children:[const Icon(Icons.search_rounded),const SizedBox(width:12),
            Expanded(child:Text(widget.t('search'),style:TextStyle(color:fg.withValues(alpha:.55)))),
            const Icon(Icons.tune_rounded)]))),
        const SizedBox(height:19),
        PremiumHero(title:widget.t('heroTitle'),button:widget.t('explore'),onTap:widget.onSubjects),
        const SizedBox(height:26),
        Row(children:[Expanded(child:Text(widget.t('subjects'),style:TextStyle(fontSize:21,fontWeight:FontWeight.w900,color:fg))),
          TextButton(onPressed:widget.onSubjects,child:Row(mainAxisSize:MainAxisSize.min,children:[Text(widget.t('explore')),const SizedBox(width:4),const Icon(Icons.arrow_forward_rounded,size:17)]))]),
        const SizedBox(height:10),
        Row(children:[
          Expanded(child:PremiumShortcut(title:widget.t('subjects'),icon:Icons.auto_stories_rounded,colors:const [Color(0xFF1B7CF6),Color(0xFF79B5FF)],onTap:widget.onSubjects)),
          const SizedBox(width:12),
          Expanded(child:PremiumShortcut(title:widget.t('vip'),icon:Icons.workspace_premium_rounded,colors:const [Color(0xFFB57A14),Color(0xFFFFDA78)],onTap:widget.onVip)),
        ]),
        const SizedBox(height:27),
        Text(widget.t('catalog'),style:TextStyle(fontSize:21,fontWeight:FontWeight.w900,color:fg)),
        const SizedBox(height:12),
        FutureBuilder<dynamic>(future:future,builder:(context,snapshot){
          if(snapshot.connectionState!=ConnectionState.done)return const Padding(padding:EdgeInsets.all(25),child:Center(child:CircularProgressIndicator()));
          if(snapshot.hasError)return ErrorPanel(error:snapshot.error!,t:widget.t,onRetry:()=>setState(()=>future=widget.api.catalog()));
          final items=extractList(snapshot.data);
          if(items.isEmpty)return _LuxuryEmpty(t:widget.t,onTap:widget.onSubjects);
          return Column(children:items.take(5).map((e)=>CourseTile(item:e,t:widget.t,api:widget.api)).toList());
        }),
      ]));
  }
}

class PremiumHero extends StatelessWidget {
  const PremiumHero({super.key,required this.title,required this.button,required this.onTap});
  final String title,button;final VoidCallback onTap;
  @override Widget build(BuildContext context)=>Container(height:254,clipBehavior:Clip.antiAlias,
    decoration:BoxDecoration(borderRadius:BorderRadius.circular(30),border:Border.all(color:const Color(0xFFB88B3D).withValues(alpha:.55)),
      boxShadow:[BoxShadow(color:const Color(0xFFB78224).withValues(alpha:.15),blurRadius:32,offset:const Offset(0,16))],
      gradient:const LinearGradient(begin:Alignment.topLeft,end:Alignment.bottomRight,colors:[Color(0xFF0C111C),Color(0xFF1D2433),Color(0xFF39280F)])),
    child:Stack(children:[
      PositionedDirectional(end:-50,top:-66,child:Container(width:215,height:215,decoration:BoxDecoration(shape:BoxShape.circle,gradient:RadialGradient(colors:[const Color(0xFFFFD27B).withValues(alpha:.30),Colors.transparent])))),
      PositionedDirectional(end:14,top:22,child:Transform.rotate(angle:-.15,child:Icon(Icons.school_rounded,size:133,color:const Color(0xFFFFC85B).withValues(alpha:.75)))),
      PositionedDirectional(end:-45,bottom:-115,child:Container(width:270,height:220,decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(color:const Color(0xFFFFD47B).withValues(alpha:.30),width:2)))),
      Padding(padding:const EdgeInsets.all(25),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:7),decoration:BoxDecoration(color:Colors.white.withValues(alpha:.10),borderRadius:BorderRadius.circular(40),border:Border.all(color:Colors.white24)),
          child:const Text('✦  EasyBAC  /  PREMIUM LEARNING',style:TextStyle(color:Color(0xFFFFD78D),fontSize:10,letterSpacing:1,fontWeight:FontWeight.w800))),
        const Spacer(),ConstrainedBox(constraints:const BoxConstraints(maxWidth:240),child:Text(title,style:const TextStyle(fontSize:28,height:1.18,color:Colors.white,fontWeight:FontWeight.w900))),
        const SizedBox(height:18),FilledButton.icon(onPressed:onTap,style:FilledButton.styleFrom(backgroundColor:const Color(0xFFFFD37B),foregroundColor:const Color(0xFF281B07),padding:const EdgeInsets.symmetric(horizontal:20,vertical:12)),
          icon:const Icon(Icons.arrow_forward_rounded),label:Text(button,style:const TextStyle(fontWeight:FontWeight.w800))),
      ])),
    ]));
}
class GlassIcon extends StatelessWidget {
  const GlassIcon({super.key,required this.icon,required this.onTap});
  final IconData icon;final VoidCallback onTap;
  @override Widget build(BuildContext context)=>Material(color:Theme.of(context).colorScheme.surface,borderRadius:BorderRadius.circular(17),child:InkWell(onTap:onTap,borderRadius:BorderRadius.circular(17),child:SizedBox(width:46,height:46,child:Icon(icon))));
}
class PremiumShortcut extends StatelessWidget {
  const PremiumShortcut({super.key,required this.title,required this.icon,required this.colors,required this.onTap});
  final String title;final IconData icon;final List<Color> colors;final VoidCallback onTap;
  @override Widget build(BuildContext context)=>Container(height:139,decoration:BoxDecoration(color:Theme.of(context).colorScheme.surface,borderRadius:BorderRadius.circular(25),border:Border.all(color:Theme.of(context).dividerColor.withValues(alpha:.16))),
    child:InkWell(onTap:onTap,borderRadius:BorderRadius.circular(25),child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Container(width:52,height:52,decoration:BoxDecoration(gradient:LinearGradient(colors:colors),borderRadius:BorderRadius.circular(17),boxShadow:[BoxShadow(color:colors.first.withValues(alpha:.25),blurRadius:18)]),child:Icon(icon,color:Colors.white,size:27)),
      const Spacer(),Row(children:[Expanded(child:Text(title,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:15))),const Icon(Icons.arrow_outward_rounded,size:18)]),
    ]))));
}

class _Feature extends StatelessWidget {
  const _Feature({required this.icon,required this.title,required this.onTap});
  final IconData icon;final String title;final VoidCallback onTap;
  @override Widget build(BuildContext context)=>Card(child:InkWell(borderRadius:BorderRadius.circular(18),onTap:onTap,
    child:Padding(padding:const EdgeInsets.symmetric(vertical:18,horizontal:8),child:Column(children:[
      Container(width:54,height:54,decoration:BoxDecoration(color:softGold,borderRadius:BorderRadius.circular(17)),child:Icon(icon,color:ink,size:28)),const SizedBox(height:9),Text(title,style:const TextStyle(fontWeight:FontWeight.w700))]))));
}
List<dynamic> extractList(dynamic data, [int depth=0]) {
  if(depth>7)return [];
  if(data is List)return data;
  if(data is Map){
    for(final key in ['items','results','data','catalog','modules','resources','lessons','subjects','courses','chapters','tracks','records']){
      final v=data[key];
      if(v is List)return v;
      if(v is Map){final nested=extractList(v,depth+1);if(nested.isNotEmpty)return nested;}
    }
    for(final v in data.values){
      if(v is List && v.isNotEmpty && v.first is Map)return v;
      if(v is Map){final nested=extractList(v,depth+1);if(nested.isNotEmpty)return nested;}
    }
  }
  return [];
}
String displayTitle(dynamic item) {
  if(item is! Map)return item.toString();
  for(final key in ['title','name','label','subject','slug']) {
    final value=item[key];
    if(value is String && value.trim().isNotEmpty)return value;
  }
  return '—';
}
String? itemValue(dynamic item,List<String> keys){
  if(item is! Map)return null;
  for(final key in keys){final v=item[key];if(v is String && v.trim().isNotEmpty)return v;}
  return null;
}
class EmptyPanel extends StatelessWidget {
  const EmptyPanel({super.key,required this.text});final String text;
  @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.all(30),child:Column(children:[
    const Icon(Icons.inbox_outlined,size:46,color:Colors.black38),const SizedBox(height:12),Text(text,textAlign:TextAlign.center)]));
}
class ErrorPanel extends StatelessWidget {
  const ErrorPanel({super.key,required this.error,required this.t,required this.onRetry});
  final Object error;final String Function(String) t;final VoidCallback onRetry;
  @override Widget build(BuildContext context){
    final e=error;
    String msg=t('error');
    if(e is ApiException){
      if(e.status==401)msg=t('sessionExpired');
      else if(e.code=='NETWORK'||e.code=='TIMEOUT')msg=t('networkError');
      else msg=e.message;
    }
    return Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[
      const Icon(Icons.error_outline,size:42,color:Colors.black45),const SizedBox(height:12),
      Text(msg,textAlign:TextAlign.center),const SizedBox(height:10),TextButton(onPressed:onRetry,child:Text(t('retry')))]));
  }
}
class CourseTile extends StatelessWidget {
  const CourseTile({super.key,required this.item,required this.t,required this.api});
  final dynamic item;final String Function(String) t;final EasyApi api;
  @override Widget build(BuildContext context){
    final vip=item is Map && (item['isVip']==true || item['requiresVip']==true || item['isPremium']==true);
    return Card(margin:const EdgeInsets.only(bottom:10),child:ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:14,vertical:6),
      leading:Container(width:52,height:52,decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFF247CFA),Color(0xFF65B4FF)]),borderRadius:BorderRadius.circular(16)),
        child:Icon(vip?Icons.workspace_premium_rounded:Icons.play_lesson_rounded,color:Colors.white)),
      title:Text(displayTitle(item),style:const TextStyle(fontWeight:FontWeight.w800)),
      subtitle:Text(itemValue(item,['description','category','mediaType'])??t('details'),maxLines:1,overflow:TextOverflow.ellipsis),
      trailing:Icon(vip?Icons.lock_outline_rounded:Icons.arrow_circle_right_rounded,color:vip?Colors.black45:gold,size:26),
      onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ContentPage(t:t,item:item,api:api)))));
  }
}
class CatalogPage extends StatefulWidget {
  const CatalogPage({super.key,required this.t,required this.api});
  final String Function(String) t;final EasyApi api;
  @override State<CatalogPage> createState()=>_CatalogPageState();
}
class _CatalogPageState extends State<CatalogPage> {
  final search=TextEditingController();
  late Future<dynamic> future;
  String category='all';
  String? track;
  @override void initState(){super.initState();future=widget.api.catalog();}
  @override void dispose(){search.dispose();super.dispose();}
  void reload(){setState(()=>future=widget.api.catalog(query:search.text,category:category,track:track));}
  @override Widget build(BuildContext context)=>Column(children:[
    Padding(padding:const EdgeInsets.fromLTRB(16,12,16,6),child:TextField(controller:search,
      decoration:InputDecoration(prefixIcon:const Icon(Icons.search),hintText:widget.t('search'),suffixIcon:IconButton(icon:const Icon(Icons.arrow_forward),onPressed:reload),
        filled:true,fillColor:Theme.of(context).colorScheme.surface,border:OutlineInputBorder(borderRadius:BorderRadius.circular(20),borderSide:BorderSide.none)),
      onSubmitted:(_)=>reload())),
    SizedBox(height:50,child:ListView(scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:14),children:[
      for(final entry in <String,String>{'all':'all','lesson_video':'videos','solved_exercise':'exercises','pdf_file':'pdfs'}.entries)
        Padding(padding:const EdgeInsets.symmetric(horizontal:4),child:ChoiceChip(label:Text(widget.t(entry.value)),
          selected:category==entry.key,selectedColor:gold,onSelected:(_){category=entry.key;reload();}))])),
    Expanded(child:FutureBuilder<dynamic>(future:future,builder:(context,snapshot){
      if(snapshot.connectionState!=ConnectionState.done)return const Center(child:CircularProgressIndicator());
      if(snapshot.hasError)return Center(child:ErrorPanel(error:snapshot.error!,t:widget.t,onRetry:reload));
      final items=extractList(snapshot.data);
      if(items.isEmpty)return Center(child:EmptyPanel(text:widget.t('empty')));
      return RefreshIndicator(onRefresh:()async{reload();await future;},child:ListView.builder(
        padding:const EdgeInsets.fromLTRB(16,10,16,120),itemCount:items.length,
        itemBuilder:(context,i)=>CourseTile(item:items[i],t:widget.t,api:widget.api)));
    })),
  ]);
}
String? resolveMediaUrl(dynamic node, [int depth=0]) {
  if(depth>5 || node is! Map)return null;
  const keys=['url','mediaUrl','fileUrl','videoUrl','downloadUrl','media_url','file_url','video_url','download_url','contentUrl','content_url','streamUrl','stream_url','pdfUrl','pdf_url','src','link','playbackUrl'];
  for(final key in keys){
    final v=node[key];
    if(v is String){final uri=Uri.tryParse(v.trim());if(uri!=null && uri.scheme=='https' && uri.host.isNotEmpty)return v.trim();}
  }
  for(final key in ['media','video','file','content','resource','attachment','assets','data','lesson']){
    final v=node[key];
    if(v is Map){final found=resolveMediaUrl(v,depth+1);if(found!=null)return found;}
    if(v is List){for(final item in v){final found=resolveMediaUrl(item,depth+1);if(found!=null)return found;}}
  }
  return null;
}
class ContentPage extends StatefulWidget {
  const ContentPage({super.key,required this.t,required this.item,required this.api});
  final String Function(String) t;final dynamic item;final EasyApi api;
  @override State<ContentPage> createState()=>_ContentPageState();
}
class _ContentPageState extends State<ContentPage> {
  Future<dynamic>? modulesFuture;
  @override void initState(){super.initState();
    final track=itemValue(widget.item,['trackSlug','track']);
    if(track!=null)modulesFuture=widget.api.modules(track);
  }
  @override Widget build(BuildContext context){
    final data=widget.item is Map?widget.item as Map:{};
    final raw=resolveMediaUrl(data);
    final link=raw==null?null:Uri.tryParse(raw);
    final allowed=link!=null && link.scheme=='https' && link.host.isNotEmpty;
    final vip=data['isVip']==true || data['requiresVip']==true || data['isPremium']==true;
    return Scaffold(appBar:AppBar(title:Text(displayTitle(widget.item))),body:ListView(padding:const EdgeInsets.fromLTRB(20,20,20,120),children:[
      Container(height:208,decoration:BoxDecoration(gradient:const LinearGradient(colors:[ink,Color(0xFF392B11)]),borderRadius:BorderRadius.circular(25)),
        child:Center(child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(vip?Icons.workspace_premium_rounded:Icons.play_circle_fill_rounded,color:gold,size:76),const SizedBox(height:9),const Text('EasyBAC',style:TextStyle(color:Colors.white70,fontWeight:FontWeight.w800,letterSpacing:2))]))),
      const SizedBox(height:20),Text(displayTitle(widget.item),style:const TextStyle(fontSize:24,fontWeight:FontWeight.w900)),
      if(data['description']!=null)...[const SizedBox(height:10),Text(data['description'].toString())],
      if(vip)...[const SizedBox(height:12),Chip(avatar:const Icon(Icons.lock_outline,size:17),label:Text(widget.t('vipContent')))],
      const SizedBox(height:24),FilledButton.icon(onPressed:allowed?()=>launchUrl(link,mode:LaunchMode.externalApplication):null,
        icon:const Icon(Icons.open_in_new),label:Text(allowed?widget.t('open'):widget.t('noLink'))),
      if(modulesFuture!=null)...[const SizedBox(height:24),Text(widget.t('modules'),style:const TextStyle(fontSize:19,fontWeight:FontWeight.w800)),
        FutureBuilder<dynamic>(future:modulesFuture,builder:(context,snapshot){
          if(snapshot.connectionState!=ConnectionState.done)return const LinearProgressIndicator();
          if(snapshot.hasError)return ErrorPanel(error:snapshot.error!,t:widget.t,onRetry:()=>setState(()=>modulesFuture=widget.api.modules(itemValue(widget.item,['trackSlug','track'])!)));
          final modules=extractList(snapshot.data);
          if(modules.isEmpty)return EmptyPanel(text:widget.t('empty'));
          return Column(children:modules.map((m)=>CourseTile(item:m,t:widget.t,api:widget.api)).toList());
        })],
    ]));
  }
}
class LoginPage extends StatefulWidget {
  const LoginPage({super.key,required this.t,required this.onAuth});
  final String Function(String) t;final Future<void> Function(String,String,bool) onAuth;
  @override State<LoginPage> createState()=>_LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final number=TextEditingController(),password=TextEditingController();
  bool signup=false,busy=false;String? error;
  @override void dispose(){number.dispose();password.dispose();super.dispose();}
  Future<void> submit() async {
    if(number.text.trim().isEmpty || password.text.isEmpty){setState(()=>error=widget.t('requiredFields'));return;}
    setState((){busy=true;error=null;});
    try {await widget.onAuth(number.text.trim(),password.text,signup);if(mounted)Navigator.pop(context);}
    catch(e){if(mounted)setState(()=>error=e is ApiException && e.status==401?widget.t('invalidCredentials'):e.toString());}
    finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(),body:ListView(padding:const EdgeInsets.all(24),children:[
    const BrandHeader(height:145),const SizedBox(height:18),
    Text(widget.t('welcome'),textAlign:TextAlign.center,style:Theme.of(context).textTheme.headlineSmall),
    const SizedBox(height:22),
    TextField(controller:number,keyboardType:TextInputType.phone,textDirection:TextDirection.ltr,decoration:InputDecoration(labelText:widget.t('phone'),border:const OutlineInputBorder())),
    const SizedBox(height:12),
    TextField(controller:password,obscureText:true,decoration:InputDecoration(labelText:widget.t('password'),border:const OutlineInputBorder())),
    const SizedBox(height:15),if(error!=null)Text(error!,style:const TextStyle(color:Colors.red)),
    ElevatedButton(onPressed:busy?null:submit,child:Text(busy?widget.t('loading'):widget.t(signup?'signup':'login'))),
    TextButton(onPressed:()=>setState(()=>signup=!signup),child:Text(widget.t(signup?'login':'signup'))),
  ]));
}
class VipPage extends StatefulWidget {
  const VipPage({super.key,required this.t,required this.api,required this.authenticated});
  final String Function(String) t;final EasyApi api;final bool authenticated;
  @override State<VipPage> createState()=>_VipPageState();
}
class _VipPageState extends State<VipPage> {
  final code=TextEditingController();
  Future<dynamic>? statusFuture;
  String? message;bool busy=false;
  @override void initState(){super.initState();refresh();}
  void refresh(){if(widget.authenticated)setState(()=>statusFuture=widget.api.vipStatus());}
  @override void dispose(){code.dispose();super.dispose();}
  String errorMessage(Object error){
    if(error is ApiException){
      if(error.status==401)return widget.t('sessionExpired');
      if(error.code=='VIP_ACTIVATION_FAILED')return widget.t('invalidVip');
      if(error.code=='NETWORK'||error.code=='TIMEOUT')return widget.t('networkError');
      return error.message;
    }
    return widget.t('error');
  }
  Future<void> activateVip() async {
    if(code.text.trim().isEmpty||busy)return;
    setState((){busy=true;message=null;});
    try {
      final result=await widget.api.activate(code.text.trim());
      if(!mounted)return;
      if(result is Map && result['success']==true){
        code.clear();setState(()=>message=widget.t('activationSuccess'));refresh();
      }else{setState(()=>message=widget.t('error'));}
    }catch(e){if(mounted)setState(()=>message=errorMessage(e));}
    finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.fromLTRB(18,18,18,120),children:[
    Container(padding:const EdgeInsets.all(26),decoration:BoxDecoration(
      gradient:const LinearGradient(begin:Alignment.topLeft,end:Alignment.bottomRight,colors:[Color(0xFF080C14),Color(0xFF22202A),Color(0xFF4A300E)]),borderRadius:BorderRadius.circular(30),border:Border.all(color:const Color(0xFFB88B3D))),
      child:Column(children:[const Icon(Icons.workspace_premium_rounded,color:Color(0xFFFFD47A),size:75),
        const Text('EasyBAC VIP',style:TextStyle(color:gold,fontSize:30,fontWeight:FontWeight.w900,letterSpacing:1)),
        const SizedBox(height:12),Text(widget.t('vipDescription'),textAlign:TextAlign.center,style:const TextStyle(color:Colors.white))])),
    const SizedBox(height:18),
    if(!widget.authenticated)EmptyPanel(text:widget.t('signInFirst'))
    else FutureBuilder<dynamic>(future:statusFuture,builder:(context,snapshot){
      if(snapshot.connectionState!=ConnectionState.done)return const Center(child:CircularProgressIndicator());
      if(snapshot.hasError)return ErrorPanel(error:snapshot.error!,t:widget.t,onRetry:refresh);
      final data=snapshot.data is Map?snapshot.data as Map:{};
      final expiry=data['vipExpiresAt']?.toString();
      return Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(children:[
        ListTile(leading:Icon(data['isVip']==true?Icons.verified:Icons.lock_outline,color:gold),
          title:Text(data['isVip']==true?widget.t('active'):widget.t('inactive'),style:const TextStyle(fontWeight:FontWeight.w800)),
          subtitle:Text('${widget.t('expires')}: ${expiry==null?'—':expiry.split('T').first}')),
        Align(alignment:AlignmentDirectional.centerEnd,child:TextButton.icon(onPressed:refresh,icon:const Icon(Icons.refresh),label:Text(widget.t('refresh'))))])));
    }),
    const SizedBox(height:20),TextField(controller:code,enabled:widget.authenticated,
      textCapitalization:TextCapitalization.characters,autocorrect:false,
      decoration:InputDecoration(labelText:widget.t('code'),prefixIcon:const Icon(Icons.key),
        filled:true,fillColor:Theme.of(context).colorScheme.surface,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14)))),
    const SizedBox(height:12),ElevatedButton(onPressed:widget.authenticated&&!busy?activateVip:null,
      child:Text(busy?widget.t('loading'):widget.t('activate'))),
    if(message!=null)Padding(padding:const EdgeInsets.only(top:15),child:Text(message!,textAlign:TextAlign.center)),
  ]);
}
class AccountPage extends StatelessWidget {
  const AccountPage({super.key,required this.t,required this.api,required this.phone,required this.onLogin,required this.onLogout});
  final String Function(String) t;final EasyApi api;final String? phone;
  final VoidCallback onLogin;final Future<void> Function() onLogout;
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.fromLTRB(20,20,20,120),children:[
    const BrandHeader(height:115),const SizedBox(height:12),
    if(api.token==null)...[Text(t('signInFirst')),const SizedBox(height:16),ElevatedButton(onPressed:onLogin,child:Text(t('login')))]
    else ...[
      Card(child:ListTile(leading:const Icon(Icons.person),title:Text(phone??'—'))),
      FutureBuilder<dynamic>(future:api.me(),builder:(context,snapshot){
        if(!snapshot.hasData)return Text(snapshot.hasError?snapshot.error.toString():t('loading'));
        final data=snapshot.data is Map?snapshot.data as Map:{};final user=data['user'] is Map?data['user'] as Map:data;return Card(child:Column(children:[ListTile(leading:const Icon(Icons.phone_outlined),title:Text(user['phone']?.toString()??phone??'—')),ListTile(leading:const Icon(Icons.workspace_premium_outlined),title:Text(user['isVip']==true?t('active'):t('inactive')))]));
      }),
      const SizedBox(height:16),OutlinedButton(onPressed:onLogout,child:Text(t('logout'))),
    ]
  ]);
}
class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key,required this.t,required this.language,required this.onChanged,required this.appearance,required this.onAppearanceChanged});
  final String Function(String) t;final String language;final Future<void> Function(String) onChanged;
  final String appearance;final Future<void> Function(String) onAppearanceChanged;
  @override Widget build(BuildContext context){
    final locale=Localizations.localeOf(context).languageCode;
    final title=locale=='ar'?'المظهر':locale=='fr'?'Apparence':'Appearance';
    String modeLabel(String v){
      if(locale=='ar')return {'system':'حسب إعدادات الجهاز','light':'فاتح','dark':'داكن'}[v]!;
      if(locale=='fr')return {'system':'Selon le système','light':'Clair','dark':'Sombre'}[v]!;
      return {'system':'System','light':'Light','dark':'Dark'}[v]!;
    }
    return Scaffold(appBar:AppBar(title:Text(t('settings'))),
      body:ListView(padding:const EdgeInsets.fromLTRB(20,20,20,50),children:[
        Text(title,style:const TextStyle(fontSize:23,fontWeight:FontWeight.w900)),
        const SizedBox(height:15),
        Row(children:[
          for(final mode in ['light','dark'])Expanded(child:Padding(
            padding:EdgeInsetsDirectional.only(end:mode=='light'?7:0,start:mode=='dark'?7:0),
            child:InkWell(onTap:()=>onAppearanceChanged(mode),borderRadius:BorderRadius.circular(24),
              child:Container(height:168,padding:const EdgeInsets.all(12),
                decoration:BoxDecoration(color:mode=='dark'?const Color(0xFF101722):const Color(0xFFEAF0F9),
                  borderRadius:BorderRadius.circular(24),border:Border.all(color:appearance==mode?gold:Colors.grey.withValues(alpha:.2),width:appearance==mode?2.5:1)),
                child:Column(children:[
                  Expanded(child:Container(decoration:BoxDecoration(color:mode=='dark'?const Color(0xFF27344A):Colors.white,borderRadius:BorderRadius.circular(15)),
                    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                      Padding(padding:const EdgeInsets.all(12),child:Container(width:45,height:8,decoration:BoxDecoration(color:gold,borderRadius:BorderRadius.circular(8)))),
                      const Spacer(),Padding(padding:const EdgeInsets.all(10),child:Container(height:37,decoration:BoxDecoration(color:mode=='dark'?const Color(0xFF42536B):const Color(0xFFDFE7F2),borderRadius:BorderRadius.circular(10)))),
                    ]))),
                  const SizedBox(height:9),Row(mainAxisAlignment:MainAxisAlignment.center,children:[
                    Icon(mode=='dark'?Icons.dark_mode_rounded:Icons.light_mode_rounded,size:17,color:mode=='dark'?Colors.white:ink),
                    const SizedBox(width:6),Text(modeLabel(mode),style:TextStyle(fontWeight:FontWeight.w800,fontSize:12,color:mode=='dark'?Colors.white:ink)),
                    if(appearance==mode)...[const SizedBox(width:4),const Icon(Icons.check_circle_rounded,color:gold,size:16)],
                  ]),
                ]))))),
        ]),
        const SizedBox(height:12),
        _LuxurySettingTile(title:modeLabel('system'),icon:Icons.brightness_auto_rounded,selected:appearance=='system',onTap:()=>onAppearanceChanged('system')),
        const SizedBox(height:28),
        Text(t('language'),style:const TextStyle(fontSize:23,fontWeight:FontWeight.w900)),
        const SizedBox(height:13),
        for(final option in ['auto','ar','en','fr'])
          _LuxurySettingTile(title:t({'auto':'automatic','ar':'arabic','en':'english','fr':'french'}[option]!),
            icon:Icons.language_rounded,selected:language==option,onTap:()=>onChanged(option)),
      ]));
  }
}


ThemeData easyTheme(Brightness brightness) {
  final dark=brightness==Brightness.dark;
  final bg=dark?const Color(0xFF080B11):const Color(0xFFF6F8FC);
  final surface=dark?const Color(0xFF151B25):Colors.white;
  final foreground=dark?const Color(0xFFF4F6FC):const Color(0xFF151B28);
  final scheme=ColorScheme.fromSeed(
    seedColor:gold,brightness:brightness,
    primary:dark?const Color(0xFFFFD37A):const Color(0xFF3B2B0A),
    surface:surface,
  );
  return ThemeData(
    useMaterial3:true,
    brightness:brightness,
    scaffoldBackgroundColor:bg,
    colorScheme:scheme,
    appBarTheme:AppBarTheme(
      backgroundColor:bg,
      foregroundColor:foreground,
      centerTitle:false,
      scrolledUnderElevation:0,
      titleTextStyle:TextStyle(color:foreground,fontSize:21,fontWeight:FontWeight.w800),
    ),
    inputDecorationTheme:InputDecorationTheme(
      filled:true,fillColor:surface,
      contentPadding:const EdgeInsets.symmetric(horizontal:18,vertical:17),
      border:OutlineInputBorder(borderRadius:BorderRadius.circular(22),borderSide:BorderSide.none),
      enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.circular(22),borderSide:BorderSide(color:dark?Colors.white12:const Color(0xFFE7EAF0))),
    ),
    elevatedButtonTheme:ElevatedButtonThemeData(style:ElevatedButton.styleFrom(
      backgroundColor:const Color(0xFFFFC85C),foregroundColor:ink,
      minimumSize:const Size.fromHeight(55),
      shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(19)),
    )),
    cardTheme:CardThemeData(
      color:surface,elevation:0,
      shape:RoundedRectangleBorder(
        borderRadius:BorderRadius.circular(25),
        side:BorderSide(color:dark?Colors.white.withValues(alpha:.08):const Color(0xFFE8EBF2)),
      ),
    ),
  );
}

class GlassBottomNav extends StatelessWidget {
  const GlassBottomNav({super.key,required this.selected,required this.onSelected,required this.labels});
  final int selected;
  final ValueChanged<int> onSelected;
  final List<String> labels;
  @override Widget build(BuildContext context) {
    final dark=Theme.of(context).brightness==Brightness.dark;
    const icons=[Icons.home_rounded,Icons.auto_stories_rounded,Icons.diamond_rounded,Icons.person_rounded];
    const outlines=[Icons.home_outlined,Icons.auto_stories_outlined,Icons.diamond_outlined,Icons.person_outline_rounded];
    return SafeArea(
      minimum:const EdgeInsets.fromLTRB(18,0,18,9),
      child:ClipRRect(
        borderRadius:BorderRadius.circular(30),
        child:BackdropFilter(
          filter:ImageFilter.blur(sigmaX:22,sigmaY:22),
          child:Container(
            height:75,
            decoration:BoxDecoration(
              color:dark?const Color(0xE31C2330):const Color(0xEAF9FBFF),
              borderRadius:BorderRadius.circular(30),
              border:Border.all(color:dark?Colors.white.withValues(alpha:.17):Colors.white.withValues(alpha:.95)),
              boxShadow:[BoxShadow(color:Colors.black.withValues(alpha: dark ? 0.30 : 0.10),blurRadius:30,offset:const Offset(0,10))],
            ),
            child:Row(children:List.generate(4,(i){
              final active=selected==i;
              return Expanded(child:Semantics(
                button:true,selected:active,label:labels[i],
                child:InkWell(
                  onTap:()=>onSelected(i),
                  borderRadius:BorderRadius.circular(26),
                  child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
                    AnimatedContainer(
                      duration:const Duration(milliseconds:230),
                      curve:Curves.easeOutCubic,
                      width:i==2?49:(active?45:39),height:i==2?43:36,
                      decoration:BoxDecoration(
                        gradient:(active||i==2)?const LinearGradient(colors:[Color(0xFFFFE4A1),Color(0xFFE7A836)]):null,
                        borderRadius:BorderRadius.circular(14),
                      ),
                      child:Icon(active?icons[i]:outlines[i],size:22,
                        color:(active||i==2)?const Color(0xFF2C210D):(dark?Colors.white70:const Color(0xFF6E7687))),
                    ),
                    const SizedBox(height:3),
                    Text(labels[i],maxLines:1,overflow:TextOverflow.ellipsis,
                      style:TextStyle(fontSize:10,fontWeight:active?FontWeight.w800:FontWeight.w500,
                        color:active?(dark?const Color(0xFFFFD37A):const Color(0xFF493410)):(dark?Colors.white60:const Color(0xFF7A8393)))),
                  ]),
                ),
              ));
            })),
          ),
        ),
      ),
    );
  }
}

class _LuxuryEmpty extends StatelessWidget {
  const _LuxuryEmpty({required this.t,required this.onTap});
  final String Function(String) t;final VoidCallback onTap;
  @override Widget build(BuildContext context)=>Container(
    padding:const EdgeInsets.symmetric(horizontal:18,vertical:26),
    decoration:BoxDecoration(color:Theme.of(context).colorScheme.surface,
      borderRadius:BorderRadius.circular(25),border:Border.all(color:Theme.of(context).dividerColor.withValues(alpha:.14))),
    child:Column(children:[
      Container(width:66,height:66,decoration:BoxDecoration(
        gradient:const LinearGradient(colors:[Color(0xFF1A283D),Color(0xFF34425A)]),
        borderRadius:BorderRadius.circular(20)),
        child:const Icon(Icons.auto_stories_rounded,color:Color(0xFFFFD17C),size:33)),
      const SizedBox(height:14),Text(t('empty'),textAlign:TextAlign.center,
        style:const TextStyle(fontWeight:FontWeight.w700)),
      const SizedBox(height:12),TextButton.icon(onPressed:onTap,
        icon:const Icon(Icons.arrow_forward_rounded),label:Text(t('subjects'))),
    ]));
}

class _LuxurySettingTile extends StatelessWidget {
  const _LuxurySettingTile({required this.title,required this.icon,required this.selected,required this.onTap});
  final String title;final IconData icon;final bool selected;final VoidCallback onTap;
  @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.only(bottom:10),
    child:Material(color:Theme.of(context).colorScheme.surface,borderRadius:BorderRadius.circular(19),
      child:InkWell(onTap:onTap,borderRadius:BorderRadius.circular(19),
        child:Container(padding:const EdgeInsets.symmetric(horizontal:16,vertical:17),
          decoration:BoxDecoration(borderRadius:BorderRadius.circular(19),
            border:Border.all(color:selected?gold:Theme.of(context).dividerColor.withValues(alpha:.15))),
          child:Row(children:[Icon(icon,color:selected?gold:Theme.of(context).colorScheme.onSurface.withValues(alpha:.65)),
            const SizedBox(width:13),Expanded(child:Text(title,style:const TextStyle(fontWeight:FontWeight.w700))),
            Icon(selected?Icons.check_circle_rounded:Icons.circle_outlined,color:selected?gold:Colors.grey,size:21)])))));
}
