
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'api.dart';
import 'translations.dart';

const gold = Color(0xFFFFC51B);
const ink = Color(0xFF121212);
const paper = Color(0xFFFAFAFC);
const softGold = Color(0xFFFFF5D8);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const EasyBacApp());
}

class EasyBacApp extends StatefulWidget {
  const EasyBacApp({super.key});
  @override State<EasyBacApp> createState() => _EasyBacAppState();
}
class _EasyBacAppState extends State<EasyBacApp> {
  final api = EasyApi();
  final storage = const FlutterSecureStorage();
  String language = 'auto';
  bool ready = false;
  int tab = 0;
  String? phone;
  int sessionVersion=0;
  @override void initState() {super.initState(); initialize();}
  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    language = prefs.getString('app_language') ?? 'auto';
    api.token = await storage.read(key:'access_token');
    phone = await storage.read(key:'phone');
    if(mounted) setState(()=>ready=true);
  }
  Future<void> changeLanguage(String value) async {
    final prefs=await SharedPreferences.getInstance();
    await prefs.setString('app_language',value);
    setState(()=>language=value);
  }
  Future<void> auth(String number,String password,bool signup) async {
    final result=await api.authenticate(number,password,signup:signup);
    api.token=result['accessToken'] as String;
    phone=number;
    await storage.write(key:'access_token',value:api.token);
    await storage.write(key:'phone',value:number);
    setState((){tab=0;sessionVersion++;});
  }
  Future<void> logout() async {
    await storage.delete(key:'access_token');
    await storage.delete(key:'phone');
    setState(() {api.token=null;phone=null;tab=0;sessionVersion++;});
  }
  @override Widget build(BuildContext context) {
    final system=WidgetsBinding.instance.platformDispatcher.locales;
    final device=system.isEmpty?'en':system.first.languageCode;
    final code=language=='auto'?(['ar','en','fr'].contains(device)?device:'en'):language;
    final locale=Locale(code);
    return MaterialApp(
      title:'EasyBAC', debugShowCheckedModeBanner:false,
      locale:locale, supportedLocales:L.supported,
      localizationsDelegates:const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],

      theme:ThemeData(useMaterial3:true,scaffoldBackgroundColor:paper,colorScheme:ColorScheme.fromSeed(seedColor:gold,primary:ink,secondary:gold,surface:Colors.white),
        appBarTheme:const AppBarTheme(backgroundColor:paper,centerTitle:true),
        elevatedButtonTheme:ElevatedButtonThemeData(style:ElevatedButton.styleFrom(backgroundColor:gold,foregroundColor:ink,
          minimumSize:const Size.fromHeight(50),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(14)))),
        cardTheme:CardThemeData(color:Colors.white,elevation:0,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18))),
      ),
      home:!ready?const Scaffold(body:Center(child:CircularProgressIndicator())):
      Builder(builder:(context){
        String t(String key)=>L.t(code,key);
        return Scaffold(
          appBar:AppBar(title:Text(t(['home','subjects','vip','account'][tab]),style:const TextStyle(fontWeight:FontWeight.w800)),
            actions:[IconButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>SettingsPage(t:t,language:language,onChanged:changeLanguage))),icon:const Icon(Icons.settings_outlined))]),
          body:IndexedStack(index:tab,children:[
            HomePage(key:ValueKey('home-$sessionVersion'),t:t,api:api,onSubjects:()=>setState(()=>tab=1),onVip:()=>setState(()=>tab=2)),
            CatalogPage(key:ValueKey('catalog-$sessionVersion'),t:t,api:api),
            VipPage(key:ValueKey('vip-$sessionVersion'),t:t,api:api,authenticated:api.token!=null),
            AccountPage(key:ValueKey('account-$sessionVersion'),t:t,api:api,phone:phone,onLogin:()=>openLogin(context,t),onLogout:logout),
          ]),
          bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),
            indicatorColor:gold,destinations:[
              NavigationDestination(icon:const Icon(Icons.home_outlined),selectedIcon:const Icon(Icons.home),label:t('home')),
              NavigationDestination(icon:const Icon(Icons.menu_book_outlined),selectedIcon:const Icon(Icons.menu_book),label:t('subjects')),
              NavigationDestination(icon:const Icon(Icons.workspace_premium_outlined),selectedIcon:const Icon(Icons.workspace_premium),label:t('vip')),
              NavigationDestination(icon:const Icon(Icons.person_outline),selectedIcon:const Icon(Icons.person),label:t('account')),
            ]),
        );
      }),
    );
  }
  Future<void> openLogin(BuildContext context,String Function(String) t) async {
    await Navigator.push(context,MaterialPageRoute(builder:(_)=>LoginPage(t:t,onAuth:auth)));
    if(mounted)setState((){});
  }
}

class BrandHeader extends StatelessWidget {
  const BrandHeader({super.key,this.height=125});
  final double height;
  @override Widget build(BuildContext context)=>Center(child:Image.asset('assets/easybac_logo.jpg',height:height,fit:BoxFit.contain));
}
class HomePage extends StatefulWidget {
  const HomePage({super.key,required this.t,required this.api,required this.onSubjects,required this.onVip});
  final String Function(String) t; final EasyApi api; final VoidCallback onSubjects,onVip;
  @override State<HomePage> createState()=>_HomePageState();
}
class _HomePageState extends State<HomePage> {
  late Future<dynamic> future;
  @override void initState(){super.initState();future=widget.api.catalog();}
  @override Widget build(BuildContext context)=>RefreshIndicator(
    onRefresh:()async{setState(()=>future=widget.api.catalog());await future;},
    child:ListView(padding:const EdgeInsets.fromLTRB(18,12,18,24),children:[
      Row(children:[const CircleAvatar(radius:23,backgroundColor:softGold,child:Icon(Icons.school,color:ink)),
        const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(widget.t('welcome'),style:const TextStyle(fontWeight:FontWeight.w800,fontSize:19)),
          Text(widget.t('subtitle'),style:const TextStyle(color:Colors.black54,fontSize:12))]))]),
      const SizedBox(height:20),
      Container(height:185,padding:const EdgeInsets.all(23),decoration:BoxDecoration(
        gradient:const LinearGradient(colors:[Color(0xFF111111),Color(0xFF40300A)]),borderRadius:BorderRadius.circular(24)),
        child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Icon(Icons.auto_stories,color:gold,size:34),const Spacer(),
          Text(widget.t('heroTitle'),style:const TextStyle(color:Colors.white,fontWeight:FontWeight.w900,fontSize:23)),
          const SizedBox(height:8),Align(alignment:AlignmentDirectional.centerStart,
            child:FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:gold,foregroundColor:ink),
              onPressed:widget.onSubjects,icon:const Icon(Icons.arrow_forward),label:Text(widget.t('explore'))))])),
      const SizedBox(height:20),
      Row(children:[Expanded(child:_Feature(icon:Icons.menu_book_rounded,title:widget.t('subjects'),onTap:widget.onSubjects)),
        const SizedBox(width:10),Expanded(child:_Feature(icon:Icons.workspace_premium_rounded,title:widget.t('vip'),onTap:widget.onVip))]),
      const SizedBox(height:22),Text(widget.t('catalog'),style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900)),
      const SizedBox(height:10),FutureBuilder<dynamic>(future:future,builder:(context,snapshot){
        if(snapshot.connectionState!=ConnectionState.done)return const Padding(padding:EdgeInsets.all(25),child:Center(child:CircularProgressIndicator()));
        if(snapshot.hasError)return ErrorPanel(error:snapshot.error!,t:widget.t,onRetry:()=>setState(()=>future=widget.api.catalog()));
        final items=extractList(snapshot.data);
        if(items.isEmpty)return EmptyPanel(text:widget.t('empty'));
        return Column(children:items.take(5).map((e)=>CourseTile(item:e,t:widget.t,api:widget.api)).toList());
      }),
    ]));
}
class _Feature extends StatelessWidget {
  const _Feature({required this.icon,required this.title,required this.onTap});
  final IconData icon;final String title;final VoidCallback onTap;
  @override Widget build(BuildContext context)=>Card(child:InkWell(borderRadius:BorderRadius.circular(18),onTap:onTap,
    child:Padding(padding:const EdgeInsets.symmetric(vertical:23,horizontal:8),child:Column(children:[
      Icon(icon,color:gold,size:35),const SizedBox(height:9),Text(title,style:const TextStyle(fontWeight:FontWeight.w700))]))));
}
List<dynamic> extractList(dynamic data) {
  if(data is List)return data;
  if(data is Map) {
    for(final key in ['items','results','data','catalog','modules','resources','lessons']) {
      final value=data[key];
      if(value is List)return value;
      if(value is Map){final nested=extractList(value);if(nested.isNotEmpty)return nested;}
    }
  }
  return [];
}
String displayTitle(dynamic item) {
  if(item is! Map)return item.toString();
  for(final key in ['title','name','label','subject','slug']) {
    final value=item[key];
    if(value is String && value.trim().isNotEmpty)return value;
  }
  return '—';
}
String? itemValue(dynamic item,List<String> keys){
  if(item is! Map)return null;
  for(final key in keys){final v=item[key];if(v is String && v.trim().isNotEmpty)return v;}
  return null;
}
class EmptyPanel extends StatelessWidget {
  const EmptyPanel({super.key,required this.text});final String text;
  @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.all(30),child:Column(children:[
    const Icon(Icons.inbox_outlined,size:46,color:Colors.black38),const SizedBox(height:12),Text(text,textAlign:TextAlign.center)]));
}
class ErrorPanel extends StatelessWidget {
  const ErrorPanel({super.key,required this.error,required this.t,required this.onRetry});
  final Object error;final String Function(String) t;final VoidCallback onRetry;
  @override Widget build(BuildContext context){
    final e=error;
    String msg=t('error');
    if(e is ApiException){
      if(e.status==401)msg=t('sessionExpired');
      else if(e.code=='NETWORK'||e.code=='TIMEOUT')msg=t('networkError');
      else msg=e.message;
    }
    return Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[
      const Icon(Icons.error_outline,size:42,color:Colors.black45),const SizedBox(height:12),
      Text(msg,textAlign:TextAlign.center),const SizedBox(height:10),TextButton(onPressed:onRetry,child:Text(t('retry')))]));
  }
}
class CourseTile extends StatelessWidget {
  const CourseTile({super.key,required this.item,required this.t,required this.api});
  final dynamic item;final String Function(String) t;final EasyApi api;
  @override Widget build(BuildContext context){
    final vip=item is Map && (item['isVip']==true || item['requiresVip']==true || item['isPremium']==true);
    return Card(margin:const EdgeInsets.only(bottom:10),child:ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:14,vertical:6),
      leading:Container(width:48,height:48,decoration:BoxDecoration(color:softGold,borderRadius:BorderRadius.circular(13)),
        child:Icon(vip?Icons.workspace_premium:Icons.menu_book_rounded,color:ink)),
      title:Text(displayTitle(item),style:const TextStyle(fontWeight:FontWeight.w800)),
      subtitle:Text(itemValue(item,['description','category','mediaType'])??t('details'),maxLines:1,overflow:TextOverflow.ellipsis),
      trailing:const Icon(Icons.chevron_right),
      onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ContentPage(t:t,item:item,api:api)))));
  }
}
class CatalogPage extends StatefulWidget {
  const CatalogPage({super.key,required this.t,required this.api});
  final String Function(String) t;final EasyApi api;
  @override State<CatalogPage> createState()=>_CatalogPageState();
}
class _CatalogPageState extends State<CatalogPage> {
  final search=TextEditingController();
  late Future<dynamic> future;
  String category='all';
  String? track;
  @override void initState(){super.initState();future=widget.api.catalog();}
  @override void dispose(){search.dispose();super.dispose();}
  void reload(){setState(()=>future=widget.api.catalog(query:search.text,category:category,track:track));}
  @override Widget build(BuildContext context)=>Column(children:[
    Padding(padding:const EdgeInsets.fromLTRB(16,12,16,6),child:TextField(controller:search,
      decoration:InputDecoration(prefixIcon:const Icon(Icons.search),hintText:widget.t('search'),suffixIcon:IconButton(icon:const Icon(Icons.arrow_forward),onPressed:reload),
        filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:BorderSide.none)),
      onSubmitted:(_)=>reload())),
    SizedBox(height:50,child:ListView(scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:14),children:[
      for(final entry in <String,String>{'all':'all','lesson_video':'videos','solved_exercise':'exercises','pdf_file':'pdfs'}.entries)
        Padding(padding:const EdgeInsets.symmetric(horizontal:4),child:ChoiceChip(label:Text(widget.t(entry.value)),
          selected:category==entry.key,selectedColor:gold,onSelected:(_){category=entry.key;reload();}))])),
    Expanded(child:FutureBuilder<dynamic>(future:future,builder:(context,snapshot){
      if(snapshot.connectionState!=ConnectionState.done)return const Center(child:CircularProgressIndicator());
      if(snapshot.hasError)return Center(child:ErrorPanel(error:snapshot.error!,t:widget.t,onRetry:reload));
      final items=extractList(snapshot.data);
      if(items.isEmpty)return Center(child:EmptyPanel(text:widget.t('empty')));
      return RefreshIndicator(onRefresh:()async{reload();await future;},child:ListView.builder(
        padding:const EdgeInsets.fromLTRB(16,10,16,30),itemCount:items.length,
        itemBuilder:(context,i)=>CourseTile(item:items[i],t:widget.t,api:widget.api)));
    })),
  ]);
}
class ContentPage extends StatefulWidget {
  const ContentPage({super.key,required this.t,required this.item,required this.api});
  final String Function(String) t;final dynamic item;final EasyApi api;
  @override State<ContentPage> createState()=>_ContentPageState();
}
class _ContentPageState extends State<ContentPage> {
  Future<dynamic>? modulesFuture;
  @override void initState(){super.initState();
    final track=itemValue(widget.item,['trackSlug','track']);
    if(track!=null)modulesFuture=widget.api.modules(track);
  }
  @override Widget build(BuildContext context){
    final data=widget.item is Map?widget.item as Map:{};
    final raw=itemValue(data,['url','mediaUrl','fileUrl','videoUrl','downloadUrl']);
    final link=raw==null?null:Uri.tryParse(raw);
    final allowed=link!=null && link.scheme=='https';
    final vip=data['isVip']==true || data['requiresVip']==true || data['isPremium']==true;
    return Scaffold(appBar:AppBar(title:Text(displayTitle(widget.item))),body:ListView(padding:const EdgeInsets.all(20),children:[
      Container(height:165,decoration:BoxDecoration(color:ink,borderRadius:BorderRadius.circular(22)),
        child:Center(child:Icon(vip?Icons.workspace_premium:Icons.ondemand_video,color:gold,size:76))),
      const SizedBox(height:20),Text(displayTitle(widget.item),style:const TextStyle(fontSize:24,fontWeight:FontWeight.w900)),
      if(data['description']!=null)...[const SizedBox(height:10),Text(data['description'].toString())],
      if(vip)...[const SizedBox(height:12),Chip(avatar:const Icon(Icons.lock_outline,size:17),label:Text(widget.t('vipContent')))],
      const SizedBox(height:24),FilledButton.icon(onPressed:allowed?()=>launchUrl(link,mode:LaunchMode.externalApplication):null,
        icon:const Icon(Icons.open_in_new),label:Text(allowed?widget.t('open'):widget.t('noLink'))),
      if(modulesFuture!=null)...[const SizedBox(height:24),Text(widget.t('modules'),style:const TextStyle(fontSize:19,fontWeight:FontWeight.w800)),
        FutureBuilder<dynamic>(future:modulesFuture,builder:(context,snapshot){
          if(snapshot.connectionState!=ConnectionState.done)return const LinearProgressIndicator();
          if(snapshot.hasError)return ErrorPanel(error:snapshot.error!,t:widget.t,onRetry:()=>setState(()=>modulesFuture=widget.api.modules(itemValue(widget.item,['trackSlug','track'])!)));
          final modules=extractList(snapshot.data);
          if(modules.isEmpty)return EmptyPanel(text:widget.t('empty'));
          return Column(children:modules.map((m)=>CourseTile(item:m,t:widget.t,api:widget.api)).toList());
        })],
    ]));
  }
}
class LoginPage extends StatefulWidget {
  const LoginPage({super.key,required this.t,required this.onAuth});
  final String Function(String) t;final Future<void> Function(String,String,bool) onAuth;
  @override State<LoginPage> createState()=>_LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final number=TextEditingController(),password=TextEditingController();
  bool signup=false,busy=false;String? error;
  @override void dispose(){number.dispose();password.dispose();super.dispose();}
  Future<void> submit() async {
    if(number.text.trim().isEmpty || password.text.isEmpty){setState(()=>error=widget.t('requiredFields'));return;}
    setState((){busy=true;error=null;});
    try {await widget.onAuth(number.text.trim(),password.text,signup);if(mounted)Navigator.pop(context);}
    catch(e){if(mounted)setState(()=>error=e is ApiException && e.status==401?widget.t('invalidCredentials'):e.toString());}
    finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(),body:ListView(padding:const EdgeInsets.all(24),children:[
    const BrandHeader(height:145),const SizedBox(height:18),
    Text(widget.t('welcome'),textAlign:TextAlign.center,style:Theme.of(context).textTheme.headlineSmall),
    const SizedBox(height:22),
    TextField(controller:number,keyboardType:TextInputType.phone,textDirection:TextDirection.ltr,decoration:InputDecoration(labelText:widget.t('phone'),border:const OutlineInputBorder())),
    const SizedBox(height:12),
    TextField(controller:password,obscureText:true,decoration:InputDecoration(labelText:widget.t('password'),border:const OutlineInputBorder())),
    const SizedBox(height:15),if(error!=null)Text(error!,style:const TextStyle(color:Colors.red)),
    ElevatedButton(onPressed:busy?null:submit,child:Text(busy?widget.t('loading'):widget.t(signup?'signup':'login'))),
    TextButton(onPressed:()=>setState(()=>signup=!signup),child:Text(widget.t(signup?'login':'signup'))),
  ]));
}
class VipPage extends StatefulWidget {
  const VipPage({super.key,required this.t,required this.api,required this.authenticated});
  final String Function(String) t;final EasyApi api;final bool authenticated;
  @override State<VipPage> createState()=>_VipPageState();
}
class _VipPageState extends State<VipPage> {
  final code=TextEditingController();
  Future<dynamic>? statusFuture;
  String? message;bool busy=false;
  @override void initState(){super.initState();refresh();}
  void refresh(){if(widget.authenticated)setState(()=>statusFuture=widget.api.vipStatus());}
  @override void dispose(){code.dispose();super.dispose();}
  String errorMessage(Object error){
    if(error is ApiException){
      if(error.status==401)return widget.t('sessionExpired');
      if(error.code=='VIP_ACTIVATION_FAILED')return widget.t('invalidVip');
      if(error.code=='NETWORK'||error.code=='TIMEOUT')return widget.t('networkError');
      return error.message;
    }
    return widget.t('error');
  }
  Future<void> activate() async {
    if(code.text.trim().isEmpty||busy)return;
    setState((){busy=true;message=null;});
    try {
      final result=await widget.api.activate(code.text.trim());
      if(!mounted)return;
      if(result is Map && result['success']==true){
        code.clear();setState(()=>message=widget.t('activationSuccess'));refresh();
      }else{setState(()=>message=widget.t('error'));}
    }catch(e){if(mounted)setState(()=>message=errorMessage(e));}
    finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    Container(padding:const EdgeInsets.all(26),decoration:BoxDecoration(
      gradient:const LinearGradient(colors:[ink,Color(0xFF473609)]),borderRadius:BorderRadius.circular(24)),
      child:Column(children:[const Icon(Icons.workspace_premium,color:gold,size:75),
        const Text('EasyBAC VIP',style:TextStyle(color:gold,fontSize:29,fontWeight:FontWeight.w900)),
        const SizedBox(height:12),Text(widget.t('vipDescription'),textAlign:TextAlign.center,style:const TextStyle(color:Colors.white))])),
    const SizedBox(height:18),
    if(!widget.authenticated)EmptyPanel(text:widget.t('signInFirst'))
    else FutureBuilder<dynamic>(future:statusFuture,builder:(context,snapshot){
      if(snapshot.connectionState!=ConnectionState.done)return const Center(child:CircularProgressIndicator());
      if(snapshot.hasError)return ErrorPanel(error:snapshot.error!,t:widget.t,onRetry:refresh);
      final data=snapshot.data is Map?snapshot.data as Map:{};
      final expiry=data['vipExpiresAt']?.toString();
      return Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(children:[
        ListTile(leading:Icon(data['isVip']==true?Icons.verified:Icons.lock_outline,color:gold),
          title:Text(data['isVip']==true?widget.t('active'):widget.t('inactive'),style:const TextStyle(fontWeight:FontWeight.w800)),
          subtitle:Text('${widget.t('expires')}: ${expiry==null?'—':expiry.split('T').first}')),
        Align(alignment:AlignmentDirectional.centerEnd,child:TextButton.icon(onPressed:refresh,icon:const Icon(Icons.refresh),label:Text(widget.t('refresh'))))])));
    }),
    const SizedBox(height:20),TextField(controller:code,enabled:widget.authenticated,
      textCapitalization:TextCapitalization.characters,autocorrect:false,
      decoration:InputDecoration(labelText:widget.t('code'),prefixIcon:const Icon(Icons.key),
        filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14)))),
    const SizedBox(height:12),ElevatedButton(onPressed:widget.authenticated&&!busy?activate:null,
      child:Text(busy?widget.t('loading'):widget.t('activate'))),
    if(message!=null)Padding(padding:const EdgeInsets.only(top:15),child:Text(message!,textAlign:TextAlign.center)),
  ]);
}
class AccountPage extends StatelessWidget {
  const AccountPage({super.key,required this.t,required this.api,required this.phone,required this.onLogin,required this.onLogout});
  final String Function(String) t;final EasyApi api;final String? phone;
  final VoidCallback onLogin;final Future<void> Function() onLogout;
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[
    const BrandHeader(height:115),const SizedBox(height:12),
    if(api.token==null)...[Text(t('signInFirst')),const SizedBox(height:16),ElevatedButton(onPressed:onLogin,child:Text(t('login')))]
    else ...[
      Card(child:ListTile(leading:const Icon(Icons.person),title:Text(phone??'—'))),
      FutureBuilder<dynamic>(future:api.me(),builder:(context,snapshot){
        if(!snapshot.hasData)return Text(snapshot.hasError?snapshot.error.toString():t('loading'));
        final data=snapshot.data is Map?snapshot.data as Map:{};final user=data['user'] is Map?data['user'] as Map:data;return Card(child:Column(children:[ListTile(leading:const Icon(Icons.phone_outlined),title:Text(user['phone']?.toString()??phone??'—')),ListTile(leading:const Icon(Icons.workspace_premium_outlined),title:Text(user['isVip']==true?t('active'):t('inactive')))]));
      }),
      const SizedBox(height:16),OutlinedButton(onPressed:onLogout,child:Text(t('logout'))),
    ]
  ]);
}
class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key,required this.t,required this.language,required this.onChanged});
  final String Function(String) t;final String language;final Future<void> Function(String) onChanged;
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(t('settings'))),
    body:ListView(padding:const EdgeInsets.all(20),children:[
      Text(t('language'),style:Theme.of(context).textTheme.titleLarge),
      const SizedBox(height:12),
      for(final option in ['auto','ar','en','fr'])
        Card(child:RadioListTile<String>(title:Text(t({'auto':'automatic','ar':'arabic','en':'english','fr':'french'}[option]!)),
          value:option,groupValue:language,onChanged:(v)async{if(v!=null)await onChanged(v);})),
    ]));
}
