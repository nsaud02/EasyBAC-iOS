import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiException implements Exception {
  final String message;
  final int status;
  final String code;
  const ApiException(this.message, this.status, [this.code = 'UNKNOWN']);
  @override String toString() => message;
}

class EasyApi {
  static const base = 'https://easybac.manus.space/api/v1';
  final http.Client _client = http.Client();
  String? token;
  void dispose() => _client.close();
  Future<dynamic> request(String method, String path,
      {Map<String, dynamic>? body, Map<String, String>? query}) async {
    final uri = Uri.parse('$base$path').replace(queryParameters: query == null || query.isEmpty ? null : query);
    if (uri.scheme != 'https') throw const ApiException('HTTPS required', 0);
    final headers = <String, String>{'Accept':'application/json', 'Content-Type':'application/json'};
    if (token != null && token!.isNotEmpty) headers['Authorization'] = 'Bearer $token';
    http.Response response;
    try {
      final req = http.Request(method, uri)..headers.addAll(headers);
      if (body != null) req.body = jsonEncode(body);
      final streamed = await _client.send(req).timeout(const Duration(seconds: 25));
      response = await http.Response.fromStream(streamed).timeout(const Duration(seconds: 25));
    } on TimeoutException {
      throw const ApiException('Request timed out', 0, 'TIMEOUT');
    } catch (_) {
      throw const ApiException('Network connection failed', 0, 'NETWORK');
    }
    dynamic parsed;
    try { parsed = response.body.isEmpty ? <String,dynamic>{} : jsonDecode(utf8.decode(response.bodyBytes)); }
    catch (_) { throw ApiException('Unexpected server response', response.statusCode, 'BAD_RESPONSE'); }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      final error = parsed is Map ? parsed['error'] : null;
      final code = error is Map ? (error['code']?.toString() ?? 'UNKNOWN') : 'UNKNOWN';
      final message = error is Map ? (error['message']?.toString() ?? 'Request failed') : 'Request failed (${response.statusCode})';
      throw ApiException(message, response.statusCode, code);
    }
    return parsed;
  }
  Future<Map<String,dynamic>> authenticate(String phone, String password, {required bool signup}) async {
    final result = await request('POST', signup ? '/auth/signup' : '/auth/login', body:{'phone':phone,'password':password});
    if (result is! Map || result['accessToken'] is! String || (result['accessToken'] as String).isEmpty) {
      throw const ApiException('Invalid authentication response', 200, 'BAD_RESPONSE');
    }
    return Map<String,dynamic>.from(result);
  }
  Future<dynamic> me() => request('GET', '/me');
  Future<dynamic> vipStatus() => request('GET', '/vip/status');
  Future<dynamic> activate(String code) => request('POST', '/vip/activate', body:{'code':code});
  Future<dynamic> catalog({String query='', String? track, String? subject, int? moduleId,
    String? category, String? mediaType, int limit=100}) {
    final filters=<String,String>{'limit':'${limit.clamp(1,100)}'};
    if(query.trim().isNotEmpty) filters['query']=query.trim();
    if(track != null && track.isNotEmpty) filters['track']=track;
    if(subject != null && subject.isNotEmpty) filters['subject']=subject;
    if(moduleId != null) filters['moduleId']='$moduleId';
    if(category != null && category != 'all') filters['category']=category;
    if(mediaType != null) filters['mediaType']=mediaType;
    return request('GET','/catalog',query:filters);
  }
  Future<dynamic> modules(String track) => request('GET','/catalog/modules',query:{'track':track});
}
