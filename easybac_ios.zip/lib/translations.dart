
import 'package:flutter/widgets.dart';

class L {
  static const supported = [Locale('ar'), Locale('en'), Locale('fr')];
  static const Map<String, Map<String, String>> data = {
    'ar': {
      'app':'EasyBAC','welcome':'مرحبًا بك في EasyBAC','subtitle':'رحلتك نحو النجاح تبدأ هنا',
      'login':'تسجيل الدخول','signup':'إنشاء حساب','phone':'رقم الهاتف','password':'كلمة المرور',
      'home':'الرئيسية','subjects':'المواد','vip':'الاشتراك','account':'حسابي',
      'settings':'الإعدادات','language':'لغة التطبيق','automatic':'حسب لغة الجهاز',
      'arabic':'العربية','english':'English','french':'Français',
      'logout':'تسجيل الخروج','catalog':'المقررات والدروس','modules':'الوحدات',
      'activate':'تفعيل الكود','code':'رمز التفعيل','vipStatus':'حالة VIP',
      'active':'نشط','inactive':'غير نشط','expires':'ينتهي في','refresh':'تحديث',
      'empty':'لا توجد عناصر للعرض','retry':'إعادة المحاولة','error':'حدث خطأ',
      'search':'البحث في المقررات','details':'التفاصيل','open':'فتح المحتوى',
      'noLink':'رابط المحتوى غير متاح','loading':'جارٍ التحميل...',
      'signInFirst':'سجّل الدخول للوصول إلى حسابك','back':'رجوع',
      'all':'الكل','lessons':'الدروس','choose':'اختر اللغة',
    },
    'en': {
      'app':'EasyBAC','welcome':'Welcome to EasyBAC','subtitle':'Your journey to success starts here',
      'login':'Sign in','signup':'Create account','phone':'Phone number','password':'Password',
      'home':'Home','subjects':'Subjects','vip':'VIP','account':'Account',
      'settings':'Settings','language':'App language','automatic':'Device language',
      'arabic':'العربية','english':'English','french':'Français',
      'logout':'Sign out','catalog':'Courses and lessons','modules':'Modules',
      'activate':'Activate code','code':'Activation code','vipStatus':'VIP status',
      'active':'Active','inactive':'Inactive','expires':'Expires on','refresh':'Refresh',
      'empty':'No items to display','retry':'Try again','error':'Something went wrong',
      'search':'Search courses','details':'Details','open':'Open content',
      'noLink':'Content link unavailable','loading':'Loading...',
      'signInFirst':'Sign in to access your account','back':'Back',
      'all':'All','lessons':'Lessons','choose':'Choose language',
    },
    'fr': {
      'app':'EasyBAC','welcome':'Bienvenue sur EasyBAC','subtitle':'Votre réussite commence ici',
      'login':'Connexion','signup':'Créer un compte','phone':'Numéro de téléphone','password':'Mot de passe',
      'home':'Accueil','subjects':'Matières','vip':'VIP','account':'Compte',
      'settings':'Paramètres','language':'Langue de l’application','automatic':'Langue de l’appareil',
      'arabic':'العربية','english':'English','french':'Français',
      'logout':'Déconnexion','catalog':'Cours et leçons','modules':'Modules',
      'activate':'Activer le code','code':'Code d’activation','vipStatus':'Statut VIP',
      'active':'Actif','inactive':'Inactif','expires':'Expire le','refresh':'Actualiser',
      'empty':'Aucun élément à afficher','retry':'Réessayer','error':'Une erreur est survenue',
      'search':'Rechercher des cours','details':'Détails','open':'Ouvrir le contenu',
      'noLink':'Lien indisponible','loading':'Chargement...',
      'signInFirst':'Connectez-vous pour accéder à votre compte','back':'Retour',
      'all':'Tout','lessons':'Leçons','choose':'Choisir la langue',
    }
  };
  static String t(String language, String key) => data[language]?[key] ?? data['en']?[key] ?? key;
}
