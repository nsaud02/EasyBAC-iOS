
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'api.dart';
import 'translations.dart';

const gold = Color(0xFFFFC51B);
const ink = Color(0xFF121212);
const paper = Color(0xFFF8F9FB);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const EasyBacApp());
}

class EasyBacApp extends StatefulWidget {
  const EasyBacApp({super.key});
  @override State<EasyBacApp> createState() => _EasyBacAppState();
}
class _EasyBacAppState extends State<EasyBacApp> {
  final api = EasyApi();
  final storage = const FlutterSecureStorage();
  String language = 'auto';
  bool ready = false;
  int tab = 0;
  String? phone;
  @override void initState() {super.initState(); initialize();}
  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    language = prefs.getString('app_language') ?? 'auto';
    api.token = await storage.read(key:'access_token');
    phone = await storage.read(key:'phone');
    if(mounted) setState(()=>ready=true);
  }
  Future<void> changeLanguage(String value) async {
    final prefs=await SharedPreferences.getInstance();
    await prefs.setString('app_language',value);
    setState(()=>language=value);
  }
  Future<void> auth(String number,String password,bool signup) async {
    final result=await api.authenticate(number,password,signup:signup);
    api.token=result['accessToken'] as String;
    phone=number;
    await storage.write(key:'access_token',value:api.token);
    await storage.write(key:'phone',value:number);
    setState(()=>tab=0);
  }
  Future<void> logout() async {
    await storage.delete(key:'access_token');
    await storage.delete(key:'phone');
    setState(() {api.token=null;phone=null;tab=0;});
  }
  @override Widget build(BuildContext context) {
    final system=WidgetsBinding.instance.platformDispatcher.locales;
    final device=system.isEmpty?'en':system.first.languageCode;
    final code=language=='auto'?(['ar','en','fr'].contains(device)?device:'en'):language;
    final locale=Locale(code);
    return MaterialApp(
      title:'EasyBAC', debugShowCheckedModeBanner:false,
      locale:locale, supportedLocales:L.supported,
      localizationsDelegates:const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
      localeResolutionCallback:(locale,supported)=>locale,
      theme:ThemeData(useMaterial3:true,scaffoldBackgroundColor:paper,colorScheme:ColorScheme.fromSeed(seedColor:gold,primary:ink,secondary:gold,surface:Colors.white),
        appBarTheme:const AppBarTheme(backgroundColor:paper,centerTitle:true),
        elevatedButtonTheme:ElevatedButtonThemeData(style:ElevatedButton.styleFrom(backgroundColor:gold,foregroundColor:ink,
          minimumSize:const Size.fromHeight(50),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(14)))),
        cardTheme:CardThemeData(color:Colors.white,elevation:0,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(18))),
      ),
      home:!ready?const Scaffold(body:Center(child:CircularProgressIndicator())):
      Builder(builder:(context){
        String t(String key)=>L.t(code,key);
        return Scaffold(
          appBar:AppBar(title:Text(t(['home','subjects','vip','account'][tab]),style:const TextStyle(fontWeight:FontWeight.bold)),
            actions:[IconButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>SettingsPage(t:t,language:language,onChanged:changeLanguage))),icon:const Icon(Icons.settings_outlined))]),
          body:IndexedStack(index:tab,children:[
            HomePage(t:t,api:api,onSubjects:()=>setState(()=>tab=1),onVip:()=>setState(()=>tab=2)),
            CatalogPage(t:t,api:api),
            VipPage(t:t,api:api,authenticated:api.token!=null),
            AccountPage(t:t,api:api,phone:phone,onLogin:()=>openLogin(context,t),onLogout:logout),
          ]),
          bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),
            indicatorColor:gold,destinations:[
              NavigationDestination(icon:const Icon(Icons.home_outlined),selectedIcon:const Icon(Icons.home),label:t('home')),
              NavigationDestination(icon:const Icon(Icons.menu_book_outlined),selectedIcon:const Icon(Icons.menu_book),label:t('subjects')),
              NavigationDestination(icon:const Icon(Icons.workspace_premium_outlined),selectedIcon:const Icon(Icons.workspace_premium),label:t('vip')),
              NavigationDestination(icon:const Icon(Icons.person_outline),selectedIcon:const Icon(Icons.person),label:t('account')),
            ]),
        );
      }),
    );
  }
  Future<void> openLogin(BuildContext context,String Function(String) t) async {
    await Navigator.push(context,MaterialPageRoute(builder:(_)=>LoginPage(t:t,onAuth:auth)));
    if(mounted)setState((){});
  }
}

class BrandHeader extends StatelessWidget {
  const BrandHeader({super.key,this.height=125});
  final double height;
  @override Widget build(BuildContext context)=>Center(child:Image.asset('assets/easybac_logo.jpg',height:height,fit:BoxFit.contain));
}
class HomePage extends StatelessWidget {
  const HomePage({super.key,required this.t,required this.api,required this.onSubjects,required this.onVip});
  final String Function(String) t; final EasyApi api; final VoidCallback onSubjects,onVip;
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    const BrandHeader(height:140),const SizedBox(height:12),
    Text(t('welcome'),style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.bold)),
    Text(t('subtitle'),style:const TextStyle(color:Colors.black54)),const SizedBox(height:18),
    Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(color:ink,borderRadius:BorderRadius.circular(22)),
      child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Icon(Icons.school,color:gold,size:40),const SizedBox(height:12),
        Text(t('catalog'),style:const TextStyle(color:Colors.white,fontSize:23,fontWeight:FontWeight.bold)),
        const SizedBox(height:14),ElevatedButton(onPressed:onSubjects,child:Text(t('subjects'))),
      ])),
    const SizedBox(height:14),
    Row(children:[
      Expanded(child:_Feature(icon:Icons.menu_book,title:t('lessons'),onTap:onSubjects)),
      const SizedBox(width:12),
      Expanded(child:_Feature(icon:Icons.workspace_premium,title:t('vip'),onTap:onVip)),
    ]),
    const SizedBox(height:20),Text(t('catalog'),style:Theme.of(context).textTheme.titleLarge),
    const SizedBox(height:8),CatalogPreview(t:t,api:api),
  ]);
}
class _Feature extends StatelessWidget {
  const _Feature({required this.icon,required this.title,required this.onTap});
  final IconData icon;final String title;final VoidCallback onTap;
  @override Widget build(BuildContext context)=>Card(child:InkWell(borderRadius:BorderRadius.circular(18),onTap:onTap,
    child:Padding(padding:const EdgeInsets.all(20),child:Column(children:[Icon(icon,color:ink,size:30),const SizedBox(height:9),Text(title)]))));
}
List<dynamic> extractList(dynamic data) {
  if(data is List)return data;
  if(data is Map) {
    for(final key in ['items','results','data','catalog','modules','resources']) {
      final value=data[key];
      if(value is List)return value;
      if(value is Map) {final nested=extractList(value);if(nested.isNotEmpty)return nested;}
    }
  }
  return [];
}
String displayTitle(dynamic item) {
  if(item is! Map)return item.toString();
  for(final key in ['title','name','label','subject','slug']) {
    if(item[key] is String && (item[key] as String).isNotEmpty)return item[key];
  }
  return '—';
}
class CatalogPreview extends StatelessWidget {
  const CatalogPreview({super.key,required this.t,required this.api});
  final String Function(String) t;final EasyApi api;
  @override Widget build(BuildContext context)=>FutureBuilder<dynamic>(future:api.catalog(),builder:(context,snapshot){
    if(!snapshot.hasData && !snapshot.hasError)return const Center(child:Padding(padding:EdgeInsets.all(25),child:CircularProgressIndicator()));
    if(snapshot.hasError)return Text('${t('error')}: ${snapshot.error}');
    final items=extractList(snapshot.data);
    if(items.isEmpty)return Text(t('empty'));
    return Column(children:items.take(4).map((e)=>Card(child:ListTile(leading:const Icon(Icons.auto_stories,color:ink),
      title:Text(displayTitle(e)),trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ContentPage(t:t,item:e)))))).toList());
  });
}
class CatalogPage extends StatefulWidget {
  const CatalogPage({super.key,required this.t,required this.api});
  final String Function(String) t;final EasyApi api;
  @override State<CatalogPage> createState()=>_CatalogPageState();
}
class _CatalogPageState extends State<CatalogPage> {
  String search='';late Future<dynamic> future;
  @override void initState(){super.initState();future=widget.api.catalog();}
  void reload(){setState(()=>future=widget.api.catalog(query:search));}
  @override Widget build(BuildContext context)=>Column(children:[
    Padding(padding:const EdgeInsets.all(16),child:TextField(
      decoration:InputDecoration(prefixIcon:const Icon(Icons.search),hintText:widget.t('search'),
        filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none)),
      onChanged:(v)=>search=v,onSubmitted:(_)=>reload())),
    Expanded(child:FutureBuilder<dynamic>(future:future,builder:(context,snapshot){
      if(!snapshot.hasData && !snapshot.hasError)return const Center(child:CircularProgressIndicator());
      if(snapshot.hasError)return Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
        Text('${widget.t('error')}: ${snapshot.error}'),TextButton(onPressed:reload,child:Text(widget.t('retry')))]));
      final items=extractList(snapshot.data);
      if(items.isEmpty)return Center(child:Text(widget.t('empty')));
      return RefreshIndicator(onRefresh:()async{reload();},child:ListView.builder(padding:const EdgeInsets.symmetric(horizontal:16),
        itemCount:items.length,itemBuilder:(context,i)=>Card(child:ListTile(
          leading:CircleAvatar(backgroundColor:gold,child:const Icon(Icons.book_outlined,color:ink)),
          title:Text(displayTitle(items[i])),subtitle:Text(widget.t('details')),
          trailing:const Icon(Icons.chevron_right),
          onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ContentPage(t:widget.t,item:items[i])))))));
    })),
  ]);
}
class ContentPage extends StatelessWidget {
  const ContentPage({super.key,required this.t,required this.item});
  final String Function(String) t;final dynamic item;
  @override Widget build(BuildContext context) {
    final data=item is Map?item as Map:{};
    final raw=data['url']??data['mediaUrl']??data['fileUrl']??data['videoUrl'];
    final link=raw is String?Uri.tryParse(raw):null;
    return Scaffold(appBar:AppBar(title:Text(displayTitle(item))),body:ListView(padding:const EdgeInsets.all(20),children:[
      const Icon(Icons.ondemand_video,size:100,color:ink),const SizedBox(height:16),
      Text(displayTitle(item),style:Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height:12),if(data['description']!=null)Text(data['description'].toString()),
      const SizedBox(height:25),
      ElevatedButton.icon(onPressed:link!=null && (link.scheme=='https'||link.scheme=='http')?()=>launchUrl(link,mode:LaunchMode.externalApplication):null,
        icon:const Icon(Icons.open_in_new),label:Text(link==null?t('noLink'):t('open'))),
    ]));
  }
}
class LoginPage extends StatefulWidget {
  const LoginPage({super.key,required this.t,required this.onAuth});
  final String Function(String) t;final Future<void> Function(String,String,bool) onAuth;
  @override State<LoginPage> createState()=>_LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final number=TextEditingController(),password=TextEditingController();
  bool signup=false,busy=false;String? error;
  @override void dispose(){number.dispose();password.dispose();super.dispose();}
  Future<void> submit() async {
    if(number.text.trim().isEmpty || password.text.isEmpty)return;
    setState((){busy=true;error=null;});
    try {await widget.onAuth(number.text.trim(),password.text,signup);if(mounted)Navigator.pop(context);}
    catch(e){if(mounted)setState(()=>error=e.toString());}
    finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(),body:ListView(padding:const EdgeInsets.all(24),children:[
    const BrandHeader(height:145),const SizedBox(height:18),
    Text(widget.t('welcome'),textAlign:TextAlign.center,style:Theme.of(context).textTheme.headlineSmall),
    const SizedBox(height:22),
    TextField(controller:number,keyboardType:TextInputType.phone,decoration:InputDecoration(labelText:widget.t('phone'),border:const OutlineInputBorder())),
    const SizedBox(height:12),
    TextField(controller:password,obscureText:true,decoration:InputDecoration(labelText:widget.t('password'),border:const OutlineInputBorder())),
    const SizedBox(height:15),if(error!=null)Text(error!,style:const TextStyle(color:Colors.red)),
    ElevatedButton(onPressed:busy?null:submit,child:Text(busy?widget.t('loading'):widget.t(signup?'signup':'login'))),
    TextButton(onPressed:()=>setState(()=>signup=!signup),child:Text(widget.t(signup?'login':'signup'))),
  ]));
}
class VipPage extends StatefulWidget {
  const VipPage({super.key,required this.t,required this.api,required this.authenticated});
  final String Function(String) t;final EasyApi api;final bool authenticated;
  @override State<VipPage> createState()=>_VipPageState();
}
class _VipPageState extends State<VipPage> {
  final code=TextEditingController();String? message;bool busy=false;
  @override void dispose(){code.dispose();super.dispose();}
  Future<void> activate() async {
    if(code.text.trim().isEmpty)return;
    setState((){busy=true;message=null;});
    try {final result=await widget.api.activate(code.text.trim());message=result.toString();}
    catch(e){message=e.toString();}
    finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    Container(padding:const EdgeInsets.all(26),decoration:BoxDecoration(color:ink,borderRadius:BorderRadius.circular(22)),
      child:Column(children:[const Icon(Icons.workspace_premium,color:gold,size:75),
        const Text('EasyBAC VIP',style:TextStyle(color:gold,fontSize:27,fontWeight:FontWeight.bold)),
        const SizedBox(height:12),Text(widget.t('vipStatus'),style:const TextStyle(color:Colors.white))])),
    const SizedBox(height:18),
    if(!widget.authenticated)Text(widget.t('signInFirst'))
    else FutureBuilder<dynamic>(future:widget.api.vipStatus(),builder:(context,snapshot){
      if(!snapshot.hasData)return Text(snapshot.hasError?snapshot.error.toString():widget.t('loading'));
      final data=snapshot.data is Map?snapshot.data as Map:{};
      return Card(child:ListTile(title:Text(data['isVip']==true?widget.t('active'):widget.t('inactive')),
        subtitle:Text('${widget.t('expires')}: ${data['vipExpiresAt']??'—'}')));
    }),
    const SizedBox(height:16),
    TextField(controller:code,enabled:widget.authenticated,decoration:InputDecoration(labelText:widget.t('code'),border:const OutlineInputBorder())),
    const SizedBox(height:12),
    ElevatedButton(onPressed:widget.authenticated && !busy?activate:null,child:Text(widget.t('activate'))),
    if(message!=null)Padding(padding:const EdgeInsets.only(top:12),child:Text(message!)),
  ]);
}
class AccountPage extends StatelessWidget {
  const AccountPage({super.key,required this.t,required this.api,required this.phone,required this.onLogin,required this.onLogout});
  final String Function(String) t;final EasyApi api;final String? phone;
  final VoidCallback onLogin;final Future<void> Function() onLogout;
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(20),children:[
    const BrandHeader(height:115),const SizedBox(height:12),
    if(api.token==null)...[Text(t('signInFirst')),const SizedBox(height:16),ElevatedButton(onPressed:onLogin,child:Text(t('login')))]
    else ...[
      Card(child:ListTile(leading:const Icon(Icons.person),title:Text(phone??'—'))),
      FutureBuilder<dynamic>(future:api.me(),builder:(context,snapshot){
        if(!snapshot.hasData)return Text(snapshot.hasError?snapshot.error.toString():t('loading'));
        return Card(child:Padding(padding:const EdgeInsets.all(16),child:Text(snapshot.data.toString())));
      }),
      const SizedBox(height:16),OutlinedButton(onPressed:onLogout,child:Text(t('logout'))),
    ]
  ]);
}
class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key,required this.t,required this.language,required this.onChanged});
  final String Function(String) t;final String language;final Future<void> Function(String) onChanged;
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(t('settings'))),
    body:ListView(padding:const EdgeInsets.all(20),children:[
      Text(t('language'),style:Theme.of(context).textTheme.titleLarge),
      const SizedBox(height:12),
      for(final option in ['auto','ar','en','fr'])
        Card(child:RadioListTile<String>(title:Text(t({'auto':'automatic','ar':'arabic','en':'english','fr':'french'}[option]!)),
          value:option,groupValue:language,onChanged:(v)async{if(v!=null)await onChanged(v);})),
    ]));
}
