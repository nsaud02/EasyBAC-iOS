
import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiException implements Exception {
  final String message;
  final int status;
  ApiException(this.message, this.status);
  @override String toString() => message;
}

class EasyApi {
  static const base = 'https://easybac.manus.space/api/v1';
  String? token;
  Future<dynamic> request(String method, String path, {Map<String,dynamic>? body, Map<String,String>? query}) async {
    final uri = Uri.parse('$base$path').replace(queryParameters: query?.isEmpty == true ? null : query);
    final headers = <String,String>{'Accept':'application/json','Content-Type':'application/json'};
    if (token != null && token!.isNotEmpty) headers['Authorization'] = 'Bearer $token';
    late http.Response response;
    try {
      final req = http.Request(method, uri); req.headers.addAll(headers); if (body != null) req.body = jsonEncode(body); response = await req.send().then(http.Response.fromStream);
    } catch (_) { throw ApiException('Network connection failed', 0); }
    dynamic parsed;
    try { parsed = jsonDecode(utf8.decode(response.bodyBytes)); }
    catch (_) { throw ApiException('Unexpected server response',response.statusCode); }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      final error = parsed is Map ? parsed['error'] : null;
      final message = error is Map ? error['message'] : null;
      throw ApiException(message?.toString() ?? 'Request failed (${response.statusCode})',response.statusCode);
    }
    return parsed;
  }
  Future<Map<String,dynamic>> authenticate(String phone,String password,{required bool signup}) async {
    final result = await request('POST',signup?'/auth/signup':'/auth/login',body:{'phone':phone,'password':password});
    if (result is! Map || result['accessToken'] is! String) throw ApiException('Invalid authentication response',200);
    return Map<String,dynamic>.from(result);
  }
  Future<dynamic> me() => request('GET','/me');
  Future<dynamic> vipStatus() => request('GET','/vip/status');
  Future<dynamic> activate(String code) => request('POST','/vip/activate',body:{'code':code});
  Future<dynamic> catalog({String query=''}) => request('GET','/catalog',query:query.isEmpty?{}:{'query':query,'limit':'100'});
  Future<dynamic> modules(String track) => request('GET','/catalog/modules',query:{'track':track});
}
